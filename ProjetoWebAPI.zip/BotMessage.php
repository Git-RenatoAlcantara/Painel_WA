<?php
include('MercadoPago.php');
include('criarUsuario.php');
include('DBController.php');

function conversation($json){
  $messages = (array) json_decode($json, true);
  $key = $messages["body"]["key"]["remoteJid"];
  $name = $messages["body"]["pushName"];
  $message =  $messages["body"]["message"]["conversation"];
  
  if(empty($message)) $message = $messages["body"]["message"]["listResponseMessage"]["singleSelectReply"]["selectedRowId"];
  
  $payload = [ 
    'message' => $message, 
    'key' => $key,
    'name' => $name,
  ];

  return $payload;
}

function saveMessage($message){
  $myfile = fopen('message.json', "w") or die("Unable to open file!");
  fwrite($myfile, $message);
  fclose($myfile);
}

function sendMessageList($id){
    $curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://n00nessh.xyz/message/list?key=c6fc1e70-4b00-41f3-a485-9aba50059ecd',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_HTTPHEADER => array(
     'Content-Type: application/json',
    'Authorization: Bearer renatoalcantara2022@gmail.com'
  ),
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{
  "id": "'.$id.'",
  "msgdata": {
      "buttonText": "ABRIR",
      "text": "",
      "title": "Clique no menu abaixo.",
      "description": "",
      "sections": [
        {
          "title": "Nosso serviço",
          "rows": [
            {
              "title": "COMPRAR ACESSO",
              "description": "Acesso ssh: 30 dias\nValor: R$ 25,00\nAcesso: 1 usuário",
              "rowId": "comprar_acesso"
            },
            {
              "title": "TESTE GRÁTIS",
              "description": "Receba um teste grátis por 1 hora.",
              "rowId": "teste_grátis"
            }
          ]
        }
      ],
      "listType": 0
    }
  }',
));

$response = curl_exec($curl);
curl_close($curl);

}


function sendMessage($id, $message){

  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL,'https://n00nessh.xyz/message/text?key=c6fc1e70-4b00-41f3-a485-9aba50059ecd');
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
  curl_setopt($curl, CURLOPT_HTTPHEADER, array(
          'Authorization: Bearer renatoalcantara2022@gmail.com')); // Inject the token into the header
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
  curl_setopt($curl, CURLOPT_RETURNTRANSFER , true);
  curl_setopt($curl, CURLOPT_TIMEOUT, 0);
  curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
  curl_setopt($curl, CURLOPT_POSTFIELDS, 'id='.$id.'&message='.$message.'');
  $response = curl_exec($curl);
  curl_close($curl);
    
}


function main_menu($jid, $name){
  
    sendMessage($jid, '👋 Olá *'.$name.'*!
Aqui você pode comprar e testar Internet Móvel 4G Ilimitada pelo melhor preço do mercado!');
        sleep(5);
        sendMessage($jid, 'Vou te mandar a lista de comandos, só um momento.');
        sleep(5);
        sendMessage($jid, '*Com qual dessas opções eu posso te ajudar.*

*1* - Comprar acesso ssh 
*2* - Criar teste
*3* - Suporte');

}


switch($_SERVER['REQUEST_METHOD']){
    case 'POST':
      
      $json = file_get_contents('php://input');
      $conversation = conversation($json);
      saveMessage($json);

      $message = strtolower($conversation["message"]);
      $jid = $conversation["key"];
      $name = $conversation["name"];
      
  
      if($message == 'oi'){
        main_menu($jid, $name);
      }else if($message == '1'){
        sendMessage($jid, '
📌  DETALHES DA COMPRA 📌
       
👜 *PRODUTO:* ACESSO VPN

💰 *PREÇO:* R$25,00 reais

📅 *VALIDADE:* 30 dias

👤 *USUÁRIOS:* limite 1 usuário

🔰 *FORMA DE PAGAMENTO:* PIX COPIA E COLA
');

    sleep(5);
    sendMessage($jid, 'Deseja comprar seu acesso de *R$ 25,00* reais?

Responda: *comprar*');
        

      }else if($message == '2'){
      

        sendMessage($jid, 'Você deseja receber um teste de 1 hora par testar o serviço?

Responda: *teste*');
         
      }else if($message == '3'){

        sendMessage($jid, 'Suporte');
        
      }else if($message == "comprar"){
        
          sendMessage($jid, '🕓 Só um momento estou gerando o seu PIX.');
          $mercadopago = new MercadoPago();
          $pedido = $mercadopago->payment();

          $dbcontroller = new DB();
          $dbcontroller->saveID($pedido["order"], $jid);
        
          sendMessage($jid, $pedido["qrcode"]);
          sendMessage($jid, 'Você receberá seu acesso automáticamente após pagar o pix acima ☝️ *ATENÇÃO* ‼️ caso seu acesso não chegue em até 5 minutos escreva no chat *_Não recebi a minha conta_* em seguida sera enviado caso seu pagamento esteja confirmado!');
        
        }else if($message == "teste"){
        
            sleep(2);
            sendMessage($jid, '🕓 Só um momento estou gerando o seu TESTE.');
        sleep(5);
            $ssh = new SSH();
            $teste = $ssh->criarTeste();
            sleep(2);
            sendMessage($jid, 'Usuário: '.$teste["nome"].' 
Senha: '.$teste["senha"].'
Limite: '.$teste["limite"].'
Tempo: '.$teste["tempo"].''); 

      }else if(preg_match("/\/pagamento:\d+:[\w]+-[\w]+-[\w]+-[\w]+-[\w]+/", $message)){
        
        $orderID = explode(':', $message)[1];
        $chatKey = explode(':', $message)[2];
        
        $access_file = file_get_contents(getcwd().'/bot_access.json');
        $key = json_decode($access_file, true)["key"];
        if($chatKey == $key){
          $dbcontroller = new DB();
          $chatid = $dbcontroller->getChatid($pedido["order"]);
          sendMessage($chatid, "Recebi o seu pagameto!");          
        }


      }
      
    
      break;
}