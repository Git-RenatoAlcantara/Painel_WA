<?php
function openAccess(){
    if(file_exists('bot_access.json')){
        $access_file = file_get_contents(getcwd().'/bot_access.json');
        return $access_file;
    }
    
}

function saveAccess($data){
    if(file_exists('bot_access.json')){
        $file_pointer = fopen(getcwd().'bot_access.json', 'w+');
        // writing on a file named gfg.txt
        fwrite($file_pointer, $data);
        fclose($file_pointer);
    }
}

// Use unlink() function to delete a file

$access_file = openAccess();
$access = json_decode($access_file, true);

$access["key"] = "c6fc1e70-4b00-41f3-a485-9aba50059ecd";
//json_encode($access, JSON_PRETTY_PRINT)
$file_pointer = fopen('bot_access.json', 'w+');
// writing on a file named gfg.txt
fwrite($file_pointer, json_encode($access, JSON_PRETTY_PRINT));
fclose($file_pointer);

//print_r($access);
