<?php

function conversation($json){
  $messages = (array) json_decode($json, true);
  $key = $messages["body"]["key"]["remoteJid"];
  $message =  $messages["body"]["message"]["conversation"];
  $payload = [ 
   'message' => $message, 
   'key' => $key 
  ];

  return $payload;
}

function saveMessage($message){
  $myfile = fopen('message.txt', "w") or die("Unable to open file!");
  fwrite($myfile, $message);
  fclose($myfile);
}

function sendMessage($id, $message){

  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL,'https://n00nessh.xyz/message/text?key=c6fc1e70-4b00-41f3-a485-9aba50059ecd');
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
  curl_setopt($curl, CURLOPT_HTTPHEADER, array(
          'Authorization: Bearer renatoalcantara2022@gmail.com')); // Inject the token into the header
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
  curl_setopt($curl, CURLOPT_RETURNTRANSFER , true);
  curl_setopt($curl, CURLOPT_TIMEOUT, 0);
  curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
  curl_setopt($curl, CURLOPT_POSTFIELDS, 'id='.$id.'&message=Olá');
  $response = curl_exec($curl);
  curl_close($curl);
    
}
switch($_SERVER['REQUEST_METHOD']){
    case 'POST':
      
      $json = file_get_contents('php://input');
      $conversation = conversation($json);
      $curl = curl_init();

      $message = $conversation["message"];
      $key = $conversation["key"];
  
      if($message == 'Oi'){
        sendMessage('5521995935415@s.whatsapp.net', $message);
      }
      
      print_r($message);
      saveMessage($message); 
      break;
}