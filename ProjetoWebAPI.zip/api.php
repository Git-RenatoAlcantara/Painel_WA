<?php


function saveAccess($data){
    
    if(file_exists(getcwd().'/bot_access.json')){
        $file_pointer = fopen(getcwd().'bot_access.json', 'w+');
        // writing on a file named gfg.txt
        fwrite($file_pointer, $data);
        fclose($file_pointer);
    }
}
function openAccess(){

    if(file_exists(getcwd().'/bot_access.json')){
        $access_file = file_get_contents(getcwd().'/bot_access.json');
        return $access_file;
    }
    
}
  
function instance_qrcode(){

    $instance = instance_init();
    sleep(2);
    $qr = request($instance["codeURL"], 'GET');
    $payload = json_decode($qr, true);
    $qrUrl = $payload["qrcode"]["url"];
    sleep(2);
    $qrcode = request($qrUrl, "GET");
    return array('code' => $qrcode, 'key' => $instance["key"]);

}

function instance_init(){

    $response = request('https://n00nessh.xyz/instance/init', 'GET');
    $convert = json_decode($response, true);
    $key = $convert["key"];
    $url = 'https://n00nessh.xyz/instance/init?key='.$key.'&webhook=true&webhookUrl=https://n00nessh.xyz/messages/receive/'.$key;
    return  array('codeURL' =>  $url, 'key' => $key);

}
function request($url, $method){


    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_USERAGENT , "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json' , 
        "Authorization: Bearer renatoalcantara2022@gmail.com" )); // Inject the token into the header
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
    curl_setopt($curl, CURLOPT_RETURNTRANSFER , true);
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_TIMEOUT, 20);

    $response = curl_exec($curl);
    curl_close($curl);

    return $response;
    //echo $key;
}

switch($_SERVER['REQUEST_METHOD'])
{
case 'GET': 
    header("Content-Type: application/json"); 
    echo '{"status": true, "method": "GET"}';
break;
case 'POST': 
  
    $json = file_get_contents('php://input');
    $post = (array) json_decode($json);
    if(isset($post["message"])){
        switch($post["message"]){
            case "adicionar":
                $celular = $post["celular"];
                $response = instance_qrcode();
                header('Content-Type: application/json; charset=utf-8');
                
                $data = $response["code"];
                $code = (array) json_decode($data);
                $key = $response["key"];
                $qrcode = $code["qrcode"];

                $payload = array('qrcode'=> $qrcode, 'mp' => 'https://n00nessh.xyz/payment?key='.$key.'&number='.$celular.'');
             
                
                $access_file = openAccess();
                $access = json_decode($access_file, true);
                $access["key"] = $key;

                saveAccess(json_encode($access, JSON_PRETTY_PRINT));
               
                echo json_encode($payload);
                break;
            case "iniciar":
             
                $user_access = openAccess();
                $access = json_decode($user_access, true);
                echo request('https://n00nessh.xyz/instance/init?key='.$access["key"].'&webhook=true&webhookUrl='.$access["webhook"].'', 'GET');
                break;

        }
    }
break;

default:
}
?>
